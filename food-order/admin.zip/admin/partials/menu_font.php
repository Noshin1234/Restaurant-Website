<?php include('../config/constraints.php');?>



<html>
    <head>
        <title> Resturent - Home page</title>

        <link rel="stylesheet" href="../css/customer.css">
        <link rel="stylesheet" href="../css/add-admin.css">
        
</head>
    <body>
        <!-- Menu Section starts-->
         <div class="menu text-center">
           <div class="wrapper">
               <ul>
                <li><a href="menucu.php">Menu</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="Blog.php">Blog</a></li>
                <li><a href="Review.php">Review</a></li>
                <li><a href="customer-service.php">Customer service</a></li>
                <li><a href="cus.php">Manage Customer</a></li>
                <li><a href="cus_logout.php">Logout</a></li>


              </div>
          </div>
        <!-- Menu Section Ends -->