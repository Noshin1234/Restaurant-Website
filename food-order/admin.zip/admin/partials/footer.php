<!-- Footer Section Starts -->
<div class="footer">
                   <div class="wrapper">
                    <p>2023 All rights reserved, Some Resturant</p> 
                     </div>
                 </div>
                 <!-- Footer Section Ends -->

</body>

</html>